# BlackHole 0.12.4 — chemins relatifs

- Encodage BH12 : nombre de remontees depuis le dossier courant, suffixe
  relatif et marqueur de slash final. Entiers non signes LEB128 bornes.
- Tous les types d'entree sont pris en charge : fichier, dossier, lien,
  solid, reference exacte, DELTA et fragments. Les cibles de references
  utilisent des chemins relatifs sans deplacer le dossier courant.
- Les cibles de liens restent litterales. Les caracteres `@` ne sont jamais
  des instructions dans les noms ni les contenus. Les valeurs de caracteres
  conservent aussi les noms representes avec des surrogate escapes.
- Metadonnees compressees avec ZSTD 9, blocs de contenu inchanges.
  Comparaison des fichiers entierement serialises : BH12 n'est retenu que
  s'il est strictement plus petit que la meilleure representation precedente.
- Lecture BH01 a BH11 conservee ; BH12 exige le lecteur 0.12.4.
- Budgets du codec BH12 : 256 Mio de metadonnees decompressees, 64 Mi
  caracteres de chemins/cibles restitues au total, 1 Mi caracteres par
  champ texte, profondeur 65 535 composants ; compteurs bornes par l'entree
  disponible et 16 777 216 elements. Les chemins hors budget a l'ecriture
  gardent l'encodage precedent. Les remontees hors racine, suffixes dangereux,
  caracteres invalides, entiers debordants/non canoniques, troncatures et
  octets supplementaires sont rejetes. Les validations habituelles des
  entrees et de l'extraction restent applicables.
- Ajout de `blackhole --version` pour identifier le programme installe.
- Tests de l'exemple utilisateur, aller-retour de tous les types, ordre
  variable, remontees longues, Unicode et noms non UTF8, fichiers contenant
  @ et NUL, anciennes metadonnees BH10 et archives malformees.

Mesure du corpus reel : 53 910 octets gagnes, archive de 69 928 291 octets.
Une compression complete : 11,92 s murales. Pas de promesse de 6–10 s ni de 25 %.
