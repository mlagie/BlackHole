# BlackHole 0.12.2 — temps et taux de compression

## Nouveau profil equilibre

`--balanced` ne se limite plus a abaisser le niveau d'un regroupement
identique a MAX. Il separe les assets, executables, .pack et textes, puis
rapproche les fichiers par paquet (dernier composant node_modules, y compris
les paquets scopes), nom de base et chemin. Les fichiers JS et source maps
d'un meme module deviennent voisins. Tous les octets restent conserves.

Les groupes font au plus 64 Mio. Les niveaux sont adaptes : assets 15,
executables 19, .pack 3, texte 16. La detection ELF lit quatre octets ; les
autres categories utilisent le chemin et l'extension. Chaque groupe est
compresse une fois, avec le meme encodeur natif que les versions precedentes.

Le profil reste une heuristique : il ne garantit pas un gain de taille sur
tous les corpus. Les fichiers uniques depassant 64 Mio gardent un decoupage
compatible avec le decodeur. Aucun nouveau format d'archive n'est introduit.

## Parallele

Les parcours direct et equilibre utilisent jusqu'a quatre travailleurs
suivant le nombre de capacites Haskell. La limite historique a un travailleur
au niveau 22 s'applique toujours au parcours exhaustif, mais ne bride plus
le parcours direct. Chaque travailleur possede son propre contexte ZSTD.
Les resultats sont restitues dans l'ordre initial et l'archive direct22
reste identique octet par octet a la reference precedente.

Ce parallelisme augmente la memoire requise pour plusieurs gros contextes
au niveau 22. Le mode equilibre emploie des niveaux et regroupements differents ;
les pics reels mesures sont disponibles dans VALIDATION-PERFORMANCE.md.

## Tests

- Determinisme de l'archive directe avec un et quatre travailleurs, sur
  plusieurs groupes physiques distincts.
- Regroupement equilibre de JS, source map, declarations, .pack, image,
  binaire ELF, doublon exact et lien relatif : sauvegarde, relecture et
  extraction exactes.
- Tests historiques et du parcours direct conserves.
- Extraction et comparaison integrales du corpus reel.
