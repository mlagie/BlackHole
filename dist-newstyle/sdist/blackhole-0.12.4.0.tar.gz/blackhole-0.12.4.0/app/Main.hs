module Main (main) where

import BlackHole.Archive
import BlackHole.Engine (Codec(..))
import Control.Exception (SomeException, displayException, try)
import Control.Concurrent.MVar (newMVar, modifyMVar_)
import Control.Monad (forM_)
import System.Environment (getArgs)
import System.Exit (exitFailure)
import System.IO (hFlush, stdout)
import System.Directory (doesPathExist)
import System.FilePath (dropExtension, (</>), takeDirectory, takeExtension, takeFileName)
import GHC.Clock (getMonotonicTimeNSec)
import qualified Data.ByteString.Lazy as BL

usage :: String
usage = unlines
  [ "BlackHole - BH06/BH07/BH08/BH09/BH10/BH11/BH12 (metadonnees separees)"
  , "  blackhole compress CHEMIN [-o ARCHIVE.bh] [--fast|--best|--ultra|--balanced] [--codec auto|zstd|math|raw]"
  , "                 [--level N (1..22)] [--direct] [--skip-symlinks|--preserve-symlinks|--follow-symlinks]"
  , "  blackhole extract ARCHIVE.bh [-o DOSSIER_SORTIE]"
  , "  blackhole ARCHIVE.bh  (extraction automatique dans un dossier deduit du nom)"
  , "  blackhole list ARCHIVE.bh"
  , "  blackhole test ARCHIVE.bh"
  , "  blackhole analyze ARCHIVE.bh"
  , "  Defaut : profil turbo, niveau 19, groupes solid et --codec auto"
  , "  --direct : un regroupement solid 64 Mio, un profil ZSTD par groupe"
  , "  --turbo : texte reversible et parallelisme natif; chemins relatifs BH12 si plus petits"
  , "  --balanced : regroupement par paquet, niveaux adaptes, jusqu'a 4 travailleurs"
  , "  --fast : niveau 1; --best : niveau 12; --ultra : niveau 15, essais solid jusqu'a 64 Mio"
  ]

main :: IO ()
main = do
  args <- getArgs
  result <- try (run args) :: IO (Either SomeException ())
  case result of
    Left err -> putStrLn ("Erreur : " ++ displayException err) >> exitFailure
    Right () -> return ()

run :: [String] -> IO ()
run ["--version"] = putStrLn "BlackHole 0.12.4"
run ("compress":source:options) = do
  let (parsedPlan, expanded) = expandDirectOptions options
      plan = if parsedPlan == SearchPlan then TurboPlan else parsedPlan
      defaultLevel = if plan == TurboPlan && not (hasQualityOption expanded) then 19 else 8
  (out, mode, codec, level) <- compressOptions (source ++ ".bh") PreserveSymlinks Auto defaultLevel expanded
  started <- getMonotonicTimeNSec
  progress <- newMVar 0
  let report done total = modifyMVar_ progress $ \lastShown -> do
        let percent = if total <= 0 then 99 else min 99 (done * 100 `div` total)
        if percent > lastShown
          then putStr ("\rCompression : " ++ show percent ++ " %") >> hFlush stdout
          else return ()
        return (max lastShown percent)
  archive <- makeArchiveWithPlanProgress plan mode codec level report source
  saveArchive out archive
  finished <- getMonotonicTimeNSec
  let elapsed = fromIntegral (finished - started) / 1000000000 :: Double
  putStrLn "\rCompression : 100 %"
  putStrLn ("Temps de compression : " ++ formatSeconds elapsed ++ " s")
  putStrLn ("Archive creee : " ++ out)
  printStats out archive
run ("extract":source:options) = do
  out <- outputOption "blackhole-extracted" options
  archive <- requireArchive source
  extractArchive out archive
  putStrLn ("Extraction terminee : " ++ out)
run [source]
  | takeExtension source == ".bh" = do
      out <- automaticOutputPath source
      archive <- requireArchive source
      extractArchive out archive
      putStrLn ("Extraction terminee : " ++ out)
run ["list", source] = do
  archive <- requireArchive source
  forM_ (archiveSummary archive) $ \(path, info) -> putStrLn (info ++ "\t" ++ path)
run ["test", source] = do
  archive <- requireArchive source
  either (ioError . userError) (const (putStrLn "Archive valide")) (verifyArchive archive)
run ["analyze", source] = requireArchive source >>= printStats source
run _ = putStrLn usage

printStats :: FilePath -> Archive -> IO ()
printStats path archive = do
  fileBytes <- BL.length <$> BL.readFile path
  let (files, original, encoded, raw, math, zstd) = archiveStats archive
      metadata = fromIntegral fileBytes - encoded
      ratio :: Double
      ratio = if original == 0 then 0 else fromIntegral fileBytes * 100 / fromIntegral original
  putStrLn ("Fichiers : " ++ show files)
  putStrLn ("Donnees d'origine : " ++ show original ++ " octets")
  putStrLn ("Blocs encodes : " ++ show encoded ++ " octets")
  putStrLn ("Surcout structure + metadonnees : " ++ show metadata ++ " octets")
  putStrLn ("Blocs : RAW=" ++ show raw ++ " MATH=" ++ show math ++ " ZSTD=" ++ show zstd)
  putStrLn ("Fonctions mathematiques stockees : " ++ show (archiveMathFunctions archive))
  putStrLn ("Archive : " ++ show fileBytes ++ " octets (" ++ show (round ratio :: Int) ++ " % des donnees originales)")

-- Consume value-taking options intact, so an output filename or codec value
-- cannot accidentally be interpreted as a quality flag.
expandDirectOptions :: [String] -> (CompressionPlan, [String])
expandDirectOptions [] = (SearchPlan, [])
expandDirectOptions ("--direct":rest) =
  let (plan, args) = expandDirectOptions rest
  in (if plan == SearchPlan then DirectPlan else plan, args)
expandDirectOptions ("--balanced":rest) =
  let (_, args) = expandDirectOptions rest in (BalancedPlan, "--level":"19":args)
expandDirectOptions ("--turbo":rest) =
  let (_, args) = expandDirectOptions rest in (TurboPlan, "--level":"19":args)
expandDirectOptions (option:value:rest)
  | option `elem` ["-o", "--codec", "--level"] =
      let (plan, args) = expandDirectOptions rest in (plan, option:value:args)
expandDirectOptions (arg:rest) =
  let (plan, args) = expandDirectOptions rest in (plan, arg:args)

hasQualityOption :: [String] -> Bool
hasQualityOption = any (`elem` ["--fast", "--best", "--ultra", "--level"])

compressOptions :: String -> SymlinkMode -> Codec -> Int -> [String] -> IO (String, SymlinkMode, Codec, Int)
compressOptions out mode codec level args = go out mode codec level False False False args
  where
    go path links compression quality seenOut seenMode seenLevel [] =
      let _ = (seenOut, seenMode, seenLevel)
      in return (path, links, compression, quality)
    go _ _ _ _ True _ _ ("-o":_) = ioError (userError "Option -o repetee")
    go _ _ _ _ _ _ _ ["-o"] = ioError (userError "Il manque le nom de sortie")
    go _ links compression quality _ seenMode seenLevel ("-o":value:rest) =
      go value links compression quality True seenMode seenLevel rest
    go path links _ quality seenOut seenMode seenLevel ("--codec":value:rest) =
      case value of
        "auto" -> go path links Auto quality seenOut seenMode seenLevel rest
        "zstd" -> go path links ZstdOnly quality seenOut seenMode seenLevel rest
        "math" -> go path links MathOnly quality seenOut seenMode seenLevel rest
        "raw" -> go path links RawOnly quality seenOut seenMode seenLevel rest
        _ -> ioError (userError "Codec inconnu : auto|zstd|math|raw")
    go path links compression _ seenOut seenMode False ("--fast":rest) =
      go path links compression 1 seenOut seenMode True rest
    go path links compression _ seenOut seenMode False ("--best":rest) =
      go path links compression 12 seenOut seenMode True rest
    go path links compression _ seenOut seenMode False ("--ultra":rest) =
      go path links compression 15 seenOut seenMode True rest
    go path links compression _ seenOut seenMode False ("--level":value:rest) =
      case reads value of
        [(parsedLevel, "")] | parsedLevel >= 1 && parsedLevel <= 22 ->
          go path links compression parsedLevel seenOut seenMode True rest
        _ -> ioError (userError "Niveau invalide : utiliser un entier de 1 a 22")
    go path _ compression quality seenOut False seenLevel ("--skip-symlinks":rest) =
      go path SkipSymlinks compression quality seenOut True seenLevel rest
    go path _ compression quality seenOut False seenLevel ("--preserve-symlinks":rest) =
      go path PreserveSymlinks compression quality seenOut True seenLevel rest
    go path _ compression quality seenOut False seenLevel ("--follow-symlinks":rest) =
      go path FollowSymlinks compression quality seenOut True seenLevel rest
    go _ _ _ _ _ _ _ _ = ioError (userError "Options invalides : voir blackhole --help")

outputOption :: String -> [String] -> IO String
outputOption defaultValue [] = return defaultValue
outputOption _ ["-o", value] = return value
outputOption _ _ = ioError (userError "Option invalide : utiliser -o CHEMIN")

automaticOutputPath :: FilePath -> IO FilePath
automaticOutputPath archive = choose (baseName archive) 0
  where
    directory = takeDirectory archive
    baseName path = directory </> dropExtension (takeFileName path)
    choose base suffix = do
      let candidate = base ++ concat (replicate suffix "-copy")
      exists <- doesPathExist candidate
      if exists then choose base (suffix + 1) else return candidate

requireArchive :: FilePath -> IO Archive
requireArchive path = do
  result <- loadArchive path
  either (ioError . userError) return result

formatSeconds :: Double -> String
formatSeconds seconds =
  let hundredths = round (seconds * 100) :: Integer
      whole = hundredths `div` 100
      fraction = hundredths `mod` 100
      fractionText = if fraction < 10 then "0" ++ show fraction else show fraction
  in show whole ++ "." ++ fractionText
