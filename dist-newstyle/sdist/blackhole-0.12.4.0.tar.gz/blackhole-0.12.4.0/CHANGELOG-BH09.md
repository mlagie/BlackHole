# BlackHole BH09 : optimisation de la structure de l'archive

## Corrections et ameliorations

- **BH09** : enveloppe ZSTD de niveau 9 facultative du flux de serialisation existant.
  Le code compare les tailles effectivement ecrites et conserve l'ancien
  format si celui-ci est plus petit.
- La representation interne des archives BH06/BH07/BH08 n'a pas change.
- La lecture de BH01 a BH08 est preservee.
- Limite de decompression BH09 a 256 Mio par securite et pour borner la RAM.
- Les buffers ZSTD de grande taille utilisent la memoire allouee et non la pile.
- `--best` revient a ZSTD niveau 12, qui avait gagne en taille sur le
  benchmark communique par l'utilisateur, au prix d'un temps plus eleve.
- Tests de regression BH09 et script `bench/compare-bh09.sh` ajoutes.

## Verification possible dans cet environnement

- Syntaxe Bash : OK
- Archive ZIP livree : verifiee
- Test binaire de l'enveloppe avec le binaire zstd sur `bulkloader.bh` :
  108296 -> 61952 octets, et restauration identique de la charge utile.
- Compilation Haskell / tests Cabal : **NON EXECUTES** (GHC indisponible).
- Benchmark EpiCine-Worker : **NON EXECUTE** (donnees non fournies).

Le ratio <= 25 % n'est pas atteint ni prouve. Ce travail est une amelioration
ciblee mesurable, pas une promesse de ratio universel.
