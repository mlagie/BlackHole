# BlackHole 0.11 — expérience solid longue distance

- Nouveau `--ultra` : ZSTD niveau 15.
- Compression de chaque groupe solid : compare les représentations RAW,
  ZSTD standard et ZSTD à fenêtre de 64 Mio (sur les groupes >= 8 Mio).
- Variante supplémentaire regroupant des fichiers de même extension / nom
  dans des groupes solid jusqu'à 32 Mio ; comparaison de l'archive binaire.
- Capacité de décompression des blocs ZSTD étendue de 16 à 64 Mio ; gros
  buffers placés sur le tas afin de ne pas épuiser la pile.
- Réduction du nombre de travailleurs ultra à 2 pour limiter la mémoire.
- Tests de reconstruction ZSTD sur un groupe solid de 9 Mio.
- Script `bench/compare-ultra.sh` comparant taille, durée et mémoire.

## Limites

Le résultat sur `EpiCine-Worker` ne peut pas être certifié sans les fichiers
source. L'objectif 25 % n'est pas garanti et ces essais augmentent le coût
CPU. Les archives préexistantes ne sont pas modifiées. `--best` conserve son
niveau de compression normal et le nouveau traitement coûteux ne s'applique
qu'à `--ultra`.
