# BlackHole 0.12 — recherche de taille minimale

- Nouvelle disposition solid de 64 Mio en qualite >=15, comparee aux
  dispositions precedentes sur les octets finaux BH10. La limite du
  decodeur reste de 64 Mio : aucun changement de format.
- Trois profils ZSTD compares par groupe : normal, fenetre de 64 Mio,
  fenetre de 64 Mio avec recherche longue distance explicitement activee.
  L'ancien profil a fenetre large est conserve : activer LDM ne gagne pas
  systematiquement. Tous les codes de retour de libzstd sont verifies.
- Les fichiers uniques de 8 a 64 Mio peuvent aussi etre compresses en
  une seule trame et compares au decoupage historique de 4 Mio.
- Niveaux explicites `--level 1` a `--level 22`. `--ultra` reste au niveau
  15. A partir du niveau 20, un seul travailleur d'archive en Auto/ZstdOnly
  limite la concurrence des gros contextes ZSTD. Ce n'est pas un plafond
  de RAM globale. Les autres budgets DELTA de 0.11.1 restent en vigueur.
- Test ajoute pour un bloc solid de 64 Mio exactement, a la limite du
  decodeur. Anciens tests et formats conserves.

## Compression normale

    blackhole compress /chemin/EpiCine-Worker --ultra -o ultra.bh +RTS -N4 -RTS
    blackhole compress /chemin/EpiCine-Worker --level 19 -o dense.bh +RTS -N4 -RTS
    blackhole compress /chemin/EpiCine-Worker --level 22 -o extreme.bh +RTS -N4 -RTS

Les niveaux 20 a 22 sont des essais plus couteux en CPU/memoire. Consulter
le rapport fourni pour les gains effectivement mesures ; 25 % n'est pas
une garantie.

## Reoptimiser une archive solid existante

L'outil de mesure suivant decompresse les originaux physiques, conserve
les noms, les doublons references, les dossiers, les liens et les DELTA,
puis teste un regroupement de 64 Mio. Il n'ecrit le candidat que s'il est
plus petit selon le serialiseur final. Une archive utilisant des chunks
n'est pas acceptee par cet outil. Les entrees physiques de plus de 64 Mio
sont conservees dans leur representation d'origine.

Depuis le projet :

    mkdir -p dist-repack
    cabal exec -- ghc -O2 -isrc -lzstd -outputdir dist-repack bench/repack-solid.hs -o dist-repack/repack-solid
    ./dist-repack/repack-solid ancienne.bh dense.bh 19
    blackhole test dense.bh

La reoptimisation evite les passes historiques de decoupage/chunks et la
recherche DELTA. Elle charge les originaux de l'archive en memoire : ce
n'est pas un outil de traitement en flux avec RAM fixe.

La definition officielle de `ZSTD_c_enableLongDistanceMatching` est dans
[la documentation libzstd 1.5.7](https://github.com/facebook/zstd/blob/v1.5.7/lib/zstd.h).
Le parametre de fenetre seul n'active pas LDM a 64 Mio.
