# BlackHole 0.12.4

Archiveur Haskell sans perte. Le profil turbo est utilise par defaut : il
conserve les optimisations texte de 0.12.3 et ajoute l'encodage relatif des
chemins quand il reduit la taille finale de l'archive.

## Installation Fedora

```bash
unzip BlackHole-0.12.4-Paths-Fedora.zip
cd BlackHole
./install-fedora.sh
blackhole --version
```

Le script compile, teste et installe dans `~/.local/bin`. Si une autre version
est trouvee en premier dans PATH, utiliser `~/.local/bin/blackhole`.
Il associe aussi les fichiers `.bh` a BlackHole : un double-clic extrait
l'archive dans un dossier portant son nom. Si ce dossier existe, un suffixe
`-copy` est ajoute, puis incremente si necessaire.
Apres une mise a jour depuis une ancienne version, relancer `./install-fedora.sh`
une fois pour enregistrer le type MIME aupres du gestionnaire de fichiers.

## Compression

```bash
blackhole compress EpiCine-Worker/ -o EpiCine-Worker.bh +RTS -N4 -RTS
blackhole test EpiCine-Worker-TURBO.bh
blackhole extract EpiCine-Worker-TURBO.bh -o restauration
# Equivalent au double-clic dans le gestionnaire de fichiers :
blackhole EpiCine-Worker-TURBO.bh
```

Tous les fichiers sont relus et recompresses a chaque execution, sans cache
persistant de blocs. Les doublons exacts sont references dans l'archive.
Le profil turbo peut employer jusqu'a quatre groupes simultanes et quatre
travailleurs ZSTD natifs par groupe ; `-N4` ne limite pas leur total a quatre.

## Chemins relatifs BH12

Pour chaque entree, le format stocke un nombre de remontees et le suffixe
restant. Le dossier courant est celui du parent du dernier fichier, ou le
dossier lui-meme pour une entree dossier. Une reference vers un autre fichier
ne deplace pas le dossier courant. Les liens symboliques gardent leur cible
litterale, y compris `..`.

Ces instructions sont des champs binaires distincts, pas des caracteres `@`.
Un nom `@fichier.js`, un saut de ligne, un nom Unicode ou un contenu contenant
`@@` ne peuvent pas etre confondus avec une remontee. Les caracteres de noms
non UTF8 conserves par l'encodage du systeme sont preservables egalement.

Les metadonnees sont ensuite compressees ensemble avec ZSTD niveau 9. Les
blocs de contenu restent identiques. L'encodeur compare les tailles finales
reelles avec les formats precedents et garde le plus petit : aucune regression
de taille introduite par le choix des chemins relatifs pour une meme archive.
Cela s'applique aussi a balanced et aux autres profils.

**Une archive BH12 exige BlackHole 0.12.4 ou plus recent pour etre lue.**
Les anciens formats BH01 a BH11 restent lisibles. L'ecriture peut encore
choisir un ancien format s'il est plus petit. Pour conserver la compatibilite
avec un lecteur ancien, employer l'ancienne version pour creer l'archive.

Sur le corpus mesure, BH12 gagne 53 910 octets : 69 928 291 octets au total,
contre 69 982 201 avec 0.12.3. Une compression complete mesuree prend 11,92 s
murales (11,81 s affiches par le programme). La cible reproductible de 6–10 s
reste ouverte ; aucun taux de 25 % n'est annonce.

## Autres profils et commandes

```bash
blackhole compress source/ --balanced -o balanced.bh +RTS -N4 -RTS
blackhole compress source/ --direct --level 22 -o direct.bh +RTS -N4 -RTS
blackhole compress source/ --level 22 -o recherche.bh +RTS -N4 -RTS
blackhole analyze archive.bh
blackhole list archive.bh
```

Les profils `--fast`, `--best`, `--ultra`, `--balanced`, `--codec auto|zstd|math|raw` et
les options de liens preserves, ignores ou suivis restent disponibles.
Turbo est le profil par defaut ; `--turbo` reste accepte pour compatibilite.
Balanced et direct restent disponibles comme profils explicites.
Le parcours physique utilise GNU find si disponible ; un repli Haskell
est conserve, notamment pour suivre les liens.

## Tests

```bash
cabal test all --test-show-details=direct
BLACKHOLE_BIN="$(cabal list-bin exe:blackhole)" ./test/direct-integration.sh
./test/native-transforms.sh
```

Le dernier test necessite les runtimes des sanitizers C. Dans un environnement
trace ou sans runtime UBSan GCC :

```bash
CC=clang ASAN_OPTIONS=detect_leaks=0 ./test/native-transforms.sh
```

Voir `VALIDATION-PERFORMANCE.md` pour le corpus, les mesures, les limites et
la verification integrale de la restauration.
