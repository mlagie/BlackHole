# BlackHole 0.12.3 — premiere compression complete

## Objectif et resultat

Sans cache de blocs persistant. Sur EpiCine-Worker fige, les trois mesures
murales completes sont 12,23 / 10,84 / 12,48 secondes, pour exactement
69 982 201 octets. Balanced mesure dans la meme session : 21,51 secondes,
70 154 057 octets. La cible de 6–10 secondes n'est pas atteinte de facon
reproductible. Le cache disque du systeme n'a pas ete purge.

## Changements

- `--turbo` : normalisation reversible des echappements, dictionnaire de
  mots embarque par bloc, puis profil ZSTD avec jobs natifs fixes.
- Les informations de restauration sont comptees dans le fichier final.
  Aucun fichier du projet n'est exclu et aucun dictionnaire externe n'est requis.
- Format BH11 pour les blocs texte : lecteur 0.12.3 requis. Lecture des anciens
  formats conservee. Balanced reste BH10, identique a la reference mesuree.
- Groupes physiques jusqu'a 64 Mio ; table lexicale de 262 144 cases avec
  au plus 64 sondes par recherche, au plus 32 640 mots dans le dictionnaire.
  Echec ou depassement de la transformation : compression ZSTD habituelle.
- Jobs ZSTD fixes de 4 Mio pour le texte, fenetre 64 Mio, chevauchement
  fixe, recherche longue distance activee. Jusqu'a quatre travailleurs natifs
  par groupe, et quatre groupes simultanes : `-N4` ne signifie pas quatre
  threads natifs au total. La memoire augmente (pic mesure environ 1,7 Gio).
- FNV natif equivalent pour la deduplication (egalite complete toujours
  verifiee) ; parcours physique GNU find ; repli Haskell pour absence de find
  ou suivi des liens ; classification reutilisant les quatre premiers octets
  deja lus ; validation des chemins avec moins d'allocations.
- Les correctifs DELTA/solid et comparaisons des tailles serialisees des
  versions precedentes sont conserves. Turbo et balanced evitent la recherche
  exhaustive DELTA pour privilegier la duree de la premiere compression.

## Validation

Compilation GHC 9.8.4 / libzstd 1.5.7 ; suite Haskell et tests CLI passes.
Aller-retour exact de tous les fichiers, dossiers et liens du corpus,
avec SHA256 par fichier. Tests des octets binaires, echappements, dictionnaires,
BH11 court, archives tronquees, limites de taille et chemins. Parcours natif
avec Unicode, saut de ligne, liens, absence de find et suivi des liens.
Test C de 1 500 iterations avec AddressSanitizer et UndefinedBehaviorSanitizer ;
detection des fuites desactivee car incompatible avec l'environnement trace.
Ces tests ne constituent pas une preuve exhaustive de tous les fichiers malformes.

Aucun taux a 25 % n'est annonce. Les temps dependent du materiel, de la
charge, du stockage, de la version de libzstd et du contenu du projet.
