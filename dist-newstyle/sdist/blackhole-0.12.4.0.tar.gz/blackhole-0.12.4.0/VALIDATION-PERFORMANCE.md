# BlackHole 0.12.4 — chemins relatifs appliques

L'encodage propose est applique aux metadonnees : **nombre de dossiers a
remonter + suffixe relatif**. Les valeurs sont des champs binaires separes.
Les noms et contenus contenant `@` restent inchanges. Les blocs de contenu
ne sont pas reencodes par cette modification du format.

## Resultat reel sur EpiCine-Worker

| Mesure | Version 0.12.3 | Version 0.12.4 |
|---|---:|---:|
| Metadonnees avant ZSTD | 3 477 938 octets | 1 262 113 octets |
| Metadonnees apres ZSTD niveau 9 | 272 706 octets | 218 796 octets |
| Structure + metadonnees affichees | 272 758 octets | 218 848 octets |
| Blocs encodes, inchanges | 69 709 443 octets | 69 709 443 octets |
| Fichier archive entier | 69 982 201 octets | **69 928 291 octets** |

Gain : **53 910 octets**, soit 19,77 % des metadonnees deja compressees et
0,077 % de l'archive entiere precedente. Le taux global devient 27,662 %
des 252 795 649 octets d'origine. Aucun fichier exclu. RAW=0, MATH=0, ZSTD=5.

Un essai complet avec le profil turbo par defaut (`+RTS -N4 -RTS`) mesure : **11,92 s murales**, dont
11,81 s affichees par le programme. Pic memoire : 1 685 088 Kio. Cette mesure
unique ne demontre pas une acceleration par rapport a 0.12.3 ; les durees
varient avec la charge. La cible reproductible de 6–10 s reste ouverte.
Tous les octets sont relus/recompresses, sans cache persistant de blocs.
Le cache disque du systeme n'a pas ete purge : pas de garantie apres un
demarrage sur stockage froid. GHC 9.8.4, libzstd 1.5.7, Linux x86_64,
16 processeurs logiques disponibles et environ 31 Gio de RAM.

## Exemple et fonctionnement

L'exemple utilisateur correspond aux chemins :

```text
p/1/login/login.js
p/1/truc.js
p/bidule.pasl
p/act/act.js
.gitignore
f1
```

Les instructions de chemin sont decodees dans les metadonnees, puis les
chemins complets sont reconstruits en memoire pour la verification et
l'extraction. Le dossier courant est le parent du dernier fichier, ou le
dossier d'une entree dossier. Les cibles des references ne deplacent pas
ce dossier courant. Les cibles des liens symboliques restent litterales.

Le fichier garde la separation entre metadonnees et blocs solid du contenu ;
il n'insere pas de marqueurs `@` au milieu des fichiers. Les champs binaires
stockent les remontees, le suffixe et le slash final eventuel. Les entiers
LEB128 sont bornes et canoniques ; les caracteres sont codes par valeur pour
preserver Unicode et les surrogate escapes des noms non UTF8 du systeme.

Le nouveau conteneur **BH12** utilise ces metadonnees, toujours compressees
avec ZSTD niveau 9. L'encodeur mesure aussi la meilleure representation
precedente BH06/BH07/BH08/BH09/BH10/BH11 et ne choisit BH12 que si le fichier
entier est strictement plus petit. Cette comparaison est aussi celle des
strategies de compression et de la sauvegarde effective.

## Compatibilite et limites

**Lire BH12 exige BlackHole 0.12.4 ou plus recent.** Le lecteur 0.12.3
rejette explicitement la nouvelle signature. Les anciens formats BH01 a
BH11 restent lisibles. Tous les profils peuvent produire BH12 si cette
representation est plus petite ; balanced n'est donc plus garanti BH10.
Pour produire une archive destinee a un lecteur ancien, conserver l'ancienne
version de l'encodeur. Une option de compatibilite explicite n'a pas ete ajoutee.

Budgets BH12 : 256 Mio de metadonnees decompressees, 64 Mi caracteres de
chemins/cibles reconstruits au total, 1 Mi caracteres par champ texte,
65 535 composants par chemin. Les compteurs sont bornes par l'entree
restante et 16 777 216 elements. Ces valeurs bornent la representation,
pas l'occupation exacte du tas Haskell. Hors budget a l'ecriture : repli
sur le meilleur format precedent. A la lecture : rejet des remontees hors
racine, suffixes dangereux, entiers invalides, caracteres hors domaine,
troncatures et octets supplementaires. Les validations habituelles des
entrees et de l'extraction restent actives.

## Verification effectuee

- Compilation reussie ; **160 assertions Haskell reussies**.
- L'exemple de l'utilisateur correspond exactement aux instructions binaires
  attendues et a l'arbre reconstruit.
- Aller-retour des fichiers, dossiers, groupes solid, liens, references
  exactes, DELTA et metadonnees de fragments.
- Unicode, noms non UTF8 representes par surrogate escapes, `@` dans un nom,
  NUL et `@` dans le contenu, slash final, sauts de ligne, ordres de fichiers
  variables et remontees depassant un octet.
- Rejet des compteurs debordants/non canoniques, suffixes absolus, `..`, NUL,
  caracteres invalides, remontees hors racine, entrees inconnues, noms trop
  longs, troncatures de chaque prefixe de l'exemple et donnees supplementaires.
- Test de lecture d'un conteneur BH10 explicite et relecture de l'archive
  BH11 reelle de 0.12.3. Le contenu Binary complet de l'archive reconstruite
  est identique avant/apres reecriture des metadonnees : tous les blocs
  compresses et toutes les entrees sont conserves exactement.
- Tests CLI turbo/direct/balanced passes. Suite historique DELTA/solid,
  deduplication, chemins et liens conservee. Le C des codecs 0.12.3 est inchange.
- La compression complete produit exactement les memes octets que la
  reecriture des seules metadonnees du fichier 0.12.3.
- Extraction integrale : **27 593 fichiers, 2 303 dossiers et 31 liens**
  identiques, SHA256 de chaque fichier et cibles de liens compares.

SHA256 de l'archive de donnees BH12 testee :
`3bcf35622cccc323de64058c0ea1c7644d30cddb159efeaff0e10b2a27bc227f`.
Empreinte de l'inventaire extrait :
`a7aa8e39f2a010ba5e2da95f45e68181400fd0415f328b129d50163f1c907ce5`.

Ces controles ne constituent pas une preuve exhaustive du rejet de toute
corruption possible. Aucune nouvelle somme de controle globale n'est ajoutee.
Le corpus et les archives contenant ses fichiers ne sont pas inclus au ZIP.

## Commande

```bash
blackhole --version
# BlackHole 0.12.4
blackhole compress EpiCine-Worker/ -o EpiCine-Worker.bh +RTS -N4 -RTS
blackhole test EpiCine-Worker-TURBO.bh
```

Le ZIP contient les sources corriges, les tests et ce rapport. Installation
Fedora via `BlackHole/install-fedora.sh`. Pour reproduire uniquement le gain
de metadonnees sans recompresser les blocs :

```bash
cabal exec -- runghc -package=blackhole bench/rewrite-paths.hs ancien.bh nouveau.bh
```
