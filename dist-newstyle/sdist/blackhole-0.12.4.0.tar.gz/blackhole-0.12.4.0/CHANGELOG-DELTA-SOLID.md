# BlackHole 0.11.1 — DELTA + solid

## Corrections

- Les variantes regular, similarity, ultra, DELTA et chunks sont comparees
  par `serializeArchive`, exactement comme `saveArchive`. La mesure inclut
  les signatures, les longueurs, les metadonnees BH10 compressees et les
  payloads. BH06/BH07/BH08, BH09 et BH10 gardent leurs formats existants.
- Le candidat DELTA part du gagnant solid. Les groupes sans cible DELTA
  sont conserves tels quels ; les groupes touches sont recompresses apres
  retrait des cibles. Aucun fichier non selectionne n'est force en RAW.
- Les bases precedant leurs cibles dans la recherche restent des originaux.
  Les DELTA sont places apres les originaux, puis les references exactes,
  y compris quand une reference exacte vise une cible DELTA. Pas de chaine
  DELTA et pas de nouveau format a installer pour lire ces archives.
- Plus de coupure globale a 10 000 chemins. Fichiers eligibles de 4 Kio a
  16 Mio, signatures de 256 octets, au moins deux signatures communes,
  deux bases maximum par cible. Les correspondances sont verifiees octet
  par octet ; un hash ne suffit jamais a produire un COPY.
- Le scan DELTA utilise un hash glissant et accumule les litteraux par
  tranche : suppression des hashes 4 Kio recalcules a chaque octet et des
  concatenations quadratiques d'instructions INSERT.

## Budgets deterministes

Pour la recherche DELTA : 128 Mio de fichiers lus, 128 Mio de tailles de
bases + cibles essayees (chaque essai est compte), cache de bases de 32 Mio, au
plus 128 signatures/fichier et 8 chemins/signature. Le cache et l'index
sont remis a zero ensemble lorsque le cache depasserait 32 Mio.
Pour chaque calcul DELTA : 16 384 ancrages maximum, 4 offsets/hash,
256 octets minimum par COPY, et environ 8*(base+cible) comparaisons d'octets.
La suite devient litterale quand ce dernier budget est epuise.

Ces budgets bornent le travail algorithmique, pas le temps en secondes.
Les 32 Mio concernent les octets des bases, pas la RAM totale : l'index,
les candidats, ZSTD et les structures Haskell ajoutent un surcout. Les
passes historiques de deduplication, chunks et comparaison solid restent
presentes et ne sont pas bornees par ce cache.

## Limites

L'index echantillonne des positions alignees ; certaines insertions ou
similitudes tombees entre les echantillons peuvent lui echapper. L'ordre
lexical et les budgets peuvent exclure des correspondances tardives.
Le filtrage local compare DELTA a un fichier compresse seul ; il reste
heuristique pour un groupe solid. La decision finale compare l'archive
hybride complete au gagnant precedent et rejette le candidat s'il grossit.
Une combinaison partielle de cibles pourrait battre ce candidat collectif.
Les essais de dispositions solid restent couteux et les tailles finales
sont recalculees lors des comparaisons et de la sauvegarde.

Aucun taux de 25 % n'est garanti. Voir le rapport de validation fourni
avec cette livraison pour les mesures effectuees sur cette machine.

## Verification

    cabal v2-build --offline all
    cabal v2-test --offline --test-show-details=direct --test-options='+RTS -N2 -RTS'
    bash test/symlinks-integration.sh

Tests ajoutes : hybride DELTA sur fichiers 32 Kio avec plus de 10 000
chemins, groupe solid intact, extraction des fichiers et des references
vers cibles DELTA, taille mesuree egale au fichier sauvegarde (dont BH10),
selection finale au plus egale au solid initial, sequences inferieures a
4 Kio, insertion decalee, long litteral et aller-retour sans perte.
