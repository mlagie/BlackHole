# BlackHole — experimental compression improvements

This update is made from the user's BH07 source snapshot.

## Implemented

- `--best` now selects ZSTD level 12 (previously level 8).
- Quality mode builds an alternative global solid grouping sorted by format and frequently repeated filenames (`package.json`, `index.js`, `index.d.ts`, etc.).
- Both BH06 candidates are compared by their actual `Data.Binary` serialized sizes; the smaller is retained. BH07 chunk-based output is still compared against the winning BH06 candidate.
- The higher-quality automatic mode allows up to 16 GHC capabilities when available (`+RTS -N... -RTS`).
- Removed quadratic `refs ++` accumulation when recording chunk references.
- Fixed BH07 archive statistics: original bytes are counted from reconstructed file fragment references, including repeated fragments, not only unique stored records.
- Added a similarity-mode lossless round-trip test and a baseline-versus-best benchmarking script.

## Scope and limitations

- No new on-disk format; existing BH06/BH07 extraction is unchanged.
- These improvements are candidates, **not proof** of a 25% ratio.
- Quality mode deliberately uses more CPU and memory; file contents are compressed for several candidates.
- Build/tests have **not** been run in this environment, as GHC/Cabal are absent. Shell scripts passed `bash -n`.
- `EpiCine-Worker` was not supplied; real compression ratio cannot be measured here.

Run on Fedora:

```sh
./install-fedora.sh
cabal test all --test-show-details=direct
./bench/compare-best.sh ./EpiCine-Worker 4
```
